'use client';

import { useEffect, useState } from "react";

export default function HomePage() {
  const [apiStatus, setApiStatus] = useState("Loading...");

  useEffect(() => {
    fetch("/api/health")
      .then(res => res.json())
      .then(data => setApiStatus(JSON.stringify(data)))
      .catch(() => setApiStatus("Error connecting to API"));
  }, []);

  return (
    <main>
      <h1>🚀 Blockwala (Vercel Edition)</h1>
      <p>Frontend + API deployed together on Vercel.</p>
      <p><b>API Health:</b> {apiStatus}</p>
    </main>
  );
}
